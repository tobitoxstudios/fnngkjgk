'use client';

import React, { useEffect, useState } from 'react';
import {
  Activity,
  ExternalLink,
  FlaskConical,
  Globe,
  RefreshCw,
  Search,
  ShieldCheck,
  X,
  ArrowUpDown,
  Phone,
  Database,
} from 'lucide-react';
import {
  ANKARA_DISTRICTS,
  ANKARA_SUMMARY_STATS,
  HAZMAT_COMPOUNDS,
  type DistrictData,
} from '@/lib/ankara-data';
import type {
  DistrictSeismicImpact,
  PostEarthquakeReport,
} from '@/lib/seismic-engine';
import type { PubChemCompoundProfile } from '@/app/api/pubchem/route';

export type ActiveModalType = 'none' | 'matrix' | 'live_feed' | 'pubchem' | 'results';

interface LiveFeedResponse {
  lastUpdatedIso: string;
  nextUpdateIso: string;
  refreshIntervalSeconds: number;
  summaryText: string;
  groundingSources: Array<{ title: string; uri: string }>;
  portalFeeds: Array<{
    institutionId: string;
    institutionName: string;
    category: string;
    status: string;
    latestNotice: string;
    portalUrl: string;
    contact: string;
  }>;
  isLiveSearchGrounded: boolean;
}

interface ModalsOverlayProps {
  activeModal: ActiveModalType;
  onClose: () => void;
  onSwitchModal?: (modal: ActiveModalType) => void;
  impactsById: Record<string, DistrictSeismicImpact>;
  postEarthquakeReport?: PostEarthquakeReport;
  onReplaySimulation?: () => void;
  onSelectDistrictFromMatrix: (districtId: string) => void;
  liveFeed: LiveFeedResponse | null;
  isRefreshingFeed: boolean;
  onForceRefreshFeed: (districtName?: string) => void;
  countdownFormatted: string;
  initialPubChemCid: number;
}

export default function ModalsOverlay({
  activeModal,
  onClose,
  onSwitchModal,
  impactsById,
  postEarthquakeReport,
  onReplaySimulation,
  onSelectDistrictFromMatrix,
  liveFeed,
  isRefreshingFeed,
  onForceRefreshFeed,
  countdownFormatted,
  initialPubChemCid,
}: ModalsOverlayProps) {
  // Matrix filter & sort states
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('ALL');
  const [sortBy, setSortBy] = useState<'pga' | 'damage' | 'pop' | 'asbestos' | 'gas'>('pga');

  // PubChem workbench states
  const [selectedCid, setSelectedCid] = useState<number>(initialPubChemCid || 297);
  const [pubchemProfile, setPubchemProfile] = useState<PubChemCompoundProfile | null>(null);
  const [isLoadingPubchem, setIsLoadingPubchem] = useState<boolean>(false);
  const [imgError, setImgError] = useState<boolean>(false);

  // Sync initialPubChemCid when opened from District Inspector
  useEffect(() => {
    if (initialPubChemCid) {
      setSelectedCid(initialPubChemCid);
    }
  }, [initialPubChemCid]);

  // Fetch PubChem profile whenever selectedCid changes and modal is pubchem
  useEffect(() => {
    if (activeModal !== 'pubchem') return;
    let cancelled = false;
    setIsLoadingPubchem(true);
    setImgError(false);

    fetch(`/api/pubchem?cid=${selectedCid}`)
      .then((res) => res.json())
      .then((data: PubChemCompoundProfile) => {
        if (!cancelled) {
          setPubchemProfile(data);
          setIsLoadingPubchem(false);
        }
      })
      .catch(() => {
        if (!cancelled) setIsLoadingPubchem(false);
      });

    return () => {
      cancelled = true;
    };
  }, [activeModal, selectedCid]);

  if (activeModal === 'none') return null;

  const filteredDistricts = ANKARA_DISTRICTS.filter((d) => {
    const matchesSearch =
      d.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.code.includes(searchQuery);
    const matchesCat = categoryFilter === 'ALL' || d.category === categoryFilter;
    return matchesSearch && matchesCat;
  }).sort((a, b) => {
    const impA = impactsById[a.id];
    const impB = impactsById[b.id];
    if (!impA || !impB) return 0;
    if (sortBy === 'pga') return impB.pgaG - impA.pgaG;
    if (sortBy === 'damage') return impB.compositeDamageScore - impA.compositeDamageScore;
    if (sortBy === 'pop') return b.population2026 - a.population2026;
    if (sortBy === 'asbestos') return b.aski.asbestosOrOldPipePercent - a.aski.asbestosOrOldPipePercent;
    return b.energy.gasSubscribers - a.energy.gasSubscribers;
  });

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={
        activeModal === 'results'
          ? 'Deprem Simülasyonu Sonuç ve Hasar Değerlendirme Raporu'
          : activeModal === 'matrix'
          ? 'Ankara 25 İlçe Sismik ve Altyapı Veri Matrisi'
          : activeModal === 'live_feed'
          ? '30 Dakikalık Canlı Veri Akışı ve Resmi Kurum Portalları'
          : 'PubChem Kimyasal ve İkincil Afet Risk Analizi'
      }
      className="fixed inset-0 z-30 flex items-center justify-center p-4 sm:p-6 bg-black/75"
    >
      <div className="w-full max-w-[1160px] max-h-[88vh] flex flex-col bg-[#0F1624] border border-slate-800 rounded-xl shadow-2xl overflow-hidden text-slate-100">
        {/* Modal Top Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-[#131C2E]">
          <div>
            <h2 className="text-lg font-bold tracking-tight text-white">
              {activeModal === 'results' &&
                'Deprem Simülasyonu Sonuç ve Altyapı Hasar Raporu (25 İlçe)'}
              {activeModal === 'matrix' &&
                '01. Ankara 25 İlçe Entegre Altyapı ve Sismik Etki Matrisi'}
              {activeModal === 'live_feed' &&
                '02. Canlı Veri Senkronizasyonu (30 Dk Periyotlu) ve Resmi Kurumlar Dizini'}
              {activeModal === 'pubchem' &&
                '03. Altyapı Kimyasal & İkincil Sismik Tehlike Analizi (PubChem PUG-REST)'}
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              {activeModal === 'results' &&
                'Sismik dalga yayılımı tamamlandı · ASKİ, Başkentgaz, Başkent EDAŞ, MEB İSG ve EGM Trafik il geneli hasar bilançosu'}
              {activeModal === 'matrix' &&
                'ABB AYKOME, ASKİ, Başkentgaz, Başkent EDAŞ, EGM Trafik ve MEB İSG verileriyle sismik kırılganlık karşılaştırması'}
              {activeModal === 'live_feed' &&
                'Google Search Grounding (gemini-3.8-flash) ve 15 resmi kurum portalı üzerinden yarım saatte bir otomatik güncellenen saha raporu'}
              {activeModal === 'pubchem' &&
                'Deprem anında doğalgaz (CH4/C3H8), asbestli içme suyu boruları (SiO2), jeotermal hatlar (H2S) ve arıtma tesislerindeki kimyasal risk profilleri'}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Pencereyi Kapat"
            className="p-2 text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* MODAL 1: 25 DISTRICT MATRIX */}
        {activeModal === 'matrix' && (
          <div className="flex-1 overflow-y-auto p-6 space-y-5">
            {/* Global Province Summary Strip */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
              <div className="p-3 bg-[#111827] border border-slate-800 rounded-lg">
                <div className="text-[11px] text-slate-400">TOPLAM NÜFUS (25 İLÇE)</div>
                <div className="text-lg font-mono font-bold tabular-nums text-white mt-0.5">
                  5.850.000
                </div>
                <div className="text-[11px] text-slate-400 font-mono">25.632 km² Yüzölçümü</div>
              </div>
              <div className="p-3 bg-[#111827] border border-slate-800 rounded-lg">
                <div className="text-[11px] text-slate-400">ASKİ BARAJ HACMİ</div>
                <div className="text-lg font-mono font-bold tabular-nums text-sky-400 mt-0.5">
                  1,45 Milyar m³
                </div>
                <div className="text-[11px] text-slate-400 font-mono">Aktif Doluluk Takipte</div>
              </div>
              <div className="p-3 bg-[#111827] border border-slate-800 rounded-lg">
                <div className="text-[11px] text-slate-400">BAŞKENTGAZ ABONE</div>
                <div className="text-lg font-mono font-bold tabular-nums text-amber-400 mt-0.5">
                  2.180.000+
                </div>
                <div className="text-[11px] text-slate-400 font-mono">25 İlçede Aktif Şebeke</div>
              </div>
              <div className="p-3 bg-[#111827] border border-slate-800 rounded-lg">
                <div className="text-[11px] text-slate-400">ORTALAMA FİBER KAPSAMA</div>
                <div className="text-lg font-mono font-bold tabular-nums text-cyan-400 mt-0.5">
                  %64,9
                </div>
                <div className="text-[11px] text-slate-400 font-mono">Metropolde %85-94</div>
              </div>
              <div className="p-3 bg-[#111827] border border-slate-800 rounded-lg">
                <div className="text-[11px] text-slate-400">KAZA KARA NOKTASI</div>
                <div className="text-lg font-mono font-bold tabular-nums text-rose-400 mt-0.5">
                  48 Kritik Nokta
                </div>
                <div className="text-[11px] text-slate-400 font-mono">EGM Trafik / KGM</div>
              </div>
              <div className="p-3 bg-[#111827] border border-slate-800 rounded-lg">
                <div className="text-[11px] text-slate-400">MEB EĞİTİM KURUMU</div>
                <div className="text-lg font-mono font-bold tabular-nums text-emerald-400 mt-0.5">
                  1.950+ Okul
                </div>
                <div className="text-[11px] text-slate-400 font-mono">Yılda 2 Tahliye Tatbikatı</div>
              </div>
            </div>

            {/* Filter & Search Toolbar */}
            <div className="flex flex-wrap items-center justify-between gap-3 bg-[#111827] p-3 rounded-lg border border-slate-800">
              <div className="flex items-center gap-2 flex-1 min-w-[220px]">
                <Search className="w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="İlçe adı veya kodu ara (örn: Çankaya, Polatlı, 07)..."
                  aria-label="İlçe Ara"
                  className="w-full bg-transparent text-xs text-slate-100 placeholder-slate-500 focus:outline-none"
                />
              </div>

              <div className="flex flex-wrap items-center gap-1.5">
                {['ALL', 'Metropol Çekirdek', 'Büyüme/Sanayi', 'Kuzey/Doğu Çevre', 'Kırsal/Dış İlçe'].map(
                  (cat) => (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setCategoryFilter(cat)}
                      className={`px-2.5 py-1 text-xs font-medium rounded transition-colors whitespace-nowrap ${
                        categoryFilter === cat
                          ? 'bg-cyan-500 text-slate-950 font-semibold'
                          : 'bg-[#0B0E17] text-slate-400 hover:text-slate-200 border border-slate-800'
                      }`}
                    >
                      {cat === 'ALL' ? 'Tüm İlçeler (25)' : cat}
                    </button>
                  )
                )}
              </div>

              <div className="flex items-center gap-2">
                <ArrowUpDown className="w-3.5 h-3.5 text-slate-400" />
                <select
                  aria-label="Sıralama Ölçütü"
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
                  className="bg-[#0B0E17] text-xs text-slate-200 border border-slate-800 rounded px-2.5 py-1 focus:outline-none"
                >
                  <option value="pga">Sırala: Yer İvmesi (PGA)</option>
                  <option value="damage">Sırala: Bileşik Hasar Skoru</option>
                  <option value="pop">Sırala: Nüfus (2026)</option>
                  <option value="asbestos">Sırala: ASKİ Asbest/Eski Boru %</option>
                  <option value="gas">Sırala: Başkentgaz Abone Sayısı</option>
                </select>
              </div>
            </div>

            {/* 25 District Data Table */}
            <div className="overflow-x-auto border border-slate-800 rounded-lg">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-[#131C2E] text-slate-300 border-b border-slate-800 font-semibold">
                    <th className="py-2.5 px-3">Kod & İlçe</th>
                    <th className="py-2.5 px-3">Kategori</th>
                    <th className="py-2.5 px-3 text-right">Nüfus</th>
                    <th className="py-2.5 px-3 text-right">PGA (g) / MMI</th>
                    <th className="py-2.5 px-3 text-right">ASKİ Eski/Asbest</th>
                    <th className="py-2.5 px-3 text-right">Başkentgaz Abone</th>
                    <th className="py-2.5 px-3 text-right">EDAŞ Yeraltı %</th>
                    <th className="py-2.5 px-3 text-right">Fiber %</th>
                    <th className="py-2.5 px-3 text-right">Hasar Skoru</th>
                    <th className="py-2.5 px-3 text-right">İşlem</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/70 font-mono tabular-nums">
                  {filteredDistricts.map((d) => {
                    const imp = impactsById[d.id];
                    return (
                      <tr
                        key={d.id}
                        className="hover:bg-slate-800/50 transition-colors text-slate-200"
                      >
                        <td className="py-2.5 px-3 font-sans font-semibold text-white whitespace-nowrap">
                          <span className="font-mono text-cyan-400 mr-1.5">[{d.code}]</span>
                          {d.name}
                        </td>
                        <td className="py-2.5 px-3 font-sans text-slate-400 whitespace-nowrap">
                          {d.category}
                        </td>
                        <td className="py-2.5 px-3 text-right">
                          {d.population2026.toLocaleString('tr-TR')}
                        </td>
                        <td className="py-2.5 px-3 text-right font-semibold text-cyan-300">
                          {imp ? `${imp.pgaG.toFixed(3)}g (${imp.mmiRoman})` : '-'}
                        </td>
                        <td className="py-2.5 px-3 text-right text-rose-300">
                          %{d.aski.asbestosOrOldPipePercent} (Kayıp %{d.aski.lossLeakagePercent})
                        </td>
                        <td className="py-2.5 px-3 text-right text-amber-300">
                          {d.energy.gasSubscribers.toLocaleString('tr-TR')}
                        </td>
                        <td className="py-2.5 px-3 text-right">
                          %{d.energy.undergroundCablePercent}
                        </td>
                        <td className="py-2.5 px-3 text-right text-emerald-300">
                          %{d.fiber.coveragePercent}
                        </td>
                        <td className="py-2.5 px-3 text-right font-bold">
                          <span
                            className={
                              (imp?.compositeDamageScore || 0) >= 65
                                ? 'text-rose-400'
                                : (imp?.compositeDamageScore || 0) >= 38
                                ? 'text-amber-400'
                                : 'text-emerald-400'
                            }
                          >
                            {imp?.compositeDamageScore || 0}/100
                          </span>
                        </td>
                        <td className="py-2.5 px-3 text-right font-sans">
                          <button
                            type="button"
                            onClick={() => {
                              onSelectDistrictFromMatrix(d.id);
                              onClose();
                            }}
                            className="px-2.5 py-1 text-xs font-medium bg-cyan-500/20 text-cyan-300 hover:bg-cyan-500 hover:text-slate-950 rounded transition-colors whitespace-nowrap"
                          >
                            3B Odakla
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* MODAL 2: 30-MINUTE LIVE FEED & 15 OFFICIAL PORTALS */}
        {activeModal === 'live_feed' && (
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            {/* Top Auto-Refresh & Search Grounding Box */}
            <div className="p-4 bg-[#111827] border border-slate-800 rounded-xl space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
                <div>
                  <div className="text-xs font-semibold text-cyan-400">
                    OTOMATİK VERİ ÇEKME PERİYODU: 30 DAKİKA (1800 SANİYE)
                  </div>
                  <div className="text-xs text-slate-400 mt-0.5 font-mono tabular-nums">
                    Son Senkronizasyon:{' '}
                    {liveFeed?.lastUpdatedIso
                      ? new Date(liveFeed.lastUpdatedIso).toLocaleTimeString('tr-TR')
                      : 'Yükleniyor...'}{' '}
                    · Sonraki Otomatik Güncelleme Kalan Süre:{' '}
                    <strong className="text-amber-400">{countdownFormatted}</strong>
                  </div>
                </div>
                <button
                  type="button"
                  disabled={isRefreshingFeed}
                  onClick={() => onForceRefreshFeed('Ankara Geneli')}
                  className="px-4 py-2 text-xs font-semibold bg-cyan-500 text-slate-950 hover:bg-cyan-400 disabled:opacity-50 rounded-lg transition-colors flex items-center gap-2 whitespace-nowrap"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isRefreshingFeed ? 'animate-spin' : ''}`} />
                  <span>{isRefreshingFeed ? 'Kaynaklar Taranıyor...' : 'Şimdi Güncelle (Canlı Veri Çek)'}</span>
                </button>
              </div>

              {/* Search Grounded Summary */}
              <div className="space-y-2">
                <div className="text-xs font-semibold text-slate-200 flex items-center gap-2">
                  <Globe className="w-4 h-4 text-cyan-400" />
                  <span>
                    Canlı Sismik ve Altyapı Durum Sentezi (Google Search Grounding · gemini-3.8-flash)
                  </span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed bg-[#0B0E17] p-3.5 rounded-lg border border-slate-800">
                  {liveFeed?.summaryText ||
                    'Ankara 25 ilçe sismik ve altyapı verileri AFAD, ASKİ, Başkent EDAŞ ve AYKOME kaynaklarından senkronize edilmektedir...'}
                </p>

                {/* Grounding Web Citations */}
                {liveFeed?.groundingSources && liveFeed.groundingSources.length > 0 && (
                  <div className="pt-1">
                    <div className="text-[11px] text-slate-400 mb-1.5">
                      Doğrulanan Web Kaynakları ve Resmi Veri Uçları:
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {liveFeed.groundingSources.map((src, i) => (
                        <a
                          key={`${src.uri}-${i}`}
                          href={src.uri}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs bg-[#0B0E17] hover:bg-slate-800 text-cyan-300 border border-slate-800 rounded transition-colors"
                        >
                          <span className="truncate max-w-[260px]">{src.title}</span>
                          <ExternalLink className="w-3 h-3 shrink-0" />
                        </a>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* 15 Official Institutions from Bölüm 3 */}
            <div className="space-y-3">
              <h3 className="text-sm font-semibold text-white">
                Bölüm 3: Resmi Kurumlar, Çağrı Merkezleri ve Çevrimiçi Portallar Dizini (15 Kurum)
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                {(liveFeed?.portalFeeds || []).map((item) => (
                  <div
                    key={item.institutionId}
                    className="p-3.5 bg-[#111827] border border-slate-800 rounded-lg flex flex-col justify-between space-y-2.5"
                  >
                    <div>
                      <div className="flex items-start justify-between gap-2">
                        <h4 className="text-xs font-semibold text-white">
                          {item.institutionName}
                        </h4>
                        <span className="text-[11px] font-mono text-emerald-400 shrink-0">
                          [{item.status}]
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-400 mt-0.5">
                        {item.category}
                      </div>
                      <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                        {item.latestNotice}
                      </p>
                    </div>

                    <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between gap-2 text-[11px]">
                      <span className="font-mono text-amber-300 flex items-center gap-1">
                        <Phone className="w-3 h-3" />
                        {item.contact}
                      </span>
                      <a
                        href={item.portalUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-cyan-400 hover:underline inline-flex items-center gap-1 font-medium"
                      >
                        <span>Resmi Portal</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* MODAL 3: PUBCHEM SECONDARY SEISMIC CHEMICAL HAZARDS WORKBENCH */}
        {activeModal === 'pubchem' && (
          <div className="flex-1 overflow-y-auto p-6 space-y-5">
            {/* Top Quick-Try Example Selector Bar (Science Skill Requirement) */}
            <div className="bg-[#111827] p-3.5 rounded-xl border border-slate-800 space-y-2">
              <div className="text-xs text-slate-400 font-medium">
                Hızlı Molekül & Altyapı Tehlike Seçimi (PubChem CID Sorgusu):
              </div>
              <div className="flex flex-wrap gap-2">
                {HAZMAT_COMPOUNDS.map((comp) => (
                  <button
                    key={comp.cid}
                    type="button"
                    onClick={() => setSelectedCid(comp.cid)}
                    className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors flex items-center gap-1.5 ${
                      selectedCid === comp.cid
                        ? 'bg-cyan-500 text-slate-950 font-semibold'
                        : 'bg-[#0B0E17] text-slate-300 hover:text-white border border-slate-800'
                    }`}
                  >
                    <FlaskConical className="w-3.5 h-3.5" />
                    <span>{comp.nameTr}</span>
                    <span className="font-mono opacity-75">({comp.formulaFallback})</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Split Interactive Structure + Synchronized Telemetry Inspector */}
            {isLoadingPubchem || !pubchemProfile ? (
              <div className="p-12 text-center text-sm text-slate-400 font-mono">
                PubChem PUG-REST veritabanından moleküler yapı ve tehlike verileri çekiliyor (CID: {selectedCid})...
              </div>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-stretch">
                {/* Left 5 Columns: 2D Chemical Structure Card */}
                <div className="lg:col-span-5 bg-[#111827] border border-slate-800 rounded-xl p-5 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between gap-2 mb-3">
                      <span className="text-xs font-mono text-cyan-400">
                        PubChem CID: {pubchemProfile.cid}
                      </span>
                      <span className="text-xs font-mono text-emerald-400">
                        {pubchemProfile.provenanceBadge}
                      </span>
                    </div>
                    <h3 className="text-base font-bold text-white">
                      {pubchemProfile.nameTr}
                    </h3>
                    <p className="text-xs font-mono text-slate-400 mt-0.5">
                      IUPAC: {pubchemProfile.iupacName}
                    </p>
                  </div>

                  {/* 2D Chemical Depiction with Resilient Fallback */}
                  <div className="my-4 bg-white rounded-lg p-4 flex items-center justify-center min-h-[220px] border border-slate-700">
                    {!imgError ? (
                      <img
                        src={pubchemProfile.image2dUrl}
                        alt={`${pubchemProfile.nameTr} 2B Kimyasal Yapısı`}
                        referrerPolicy="no-referrer"
                        onError={() => setImgError(true)}
                        className="max-h-[190px] w-auto object-contain"
                      />
                    ) : (
                      <div className="text-center text-slate-800 p-4 space-y-2">
                        <FlaskConical className="w-10 h-10 mx-auto text-cyan-700" />
                        <div className="font-mono text-lg font-bold">
                          {pubchemProfile.molecularFormula}
                        </div>
                        <div className="font-mono text-xs text-slate-600">
                          SMILES: {pubchemProfile.canonicalSmiles}
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-xs">
                    <span className="text-rose-400 font-semibold">
                      GHS Sinyal: {pubchemProfile.ghsSignal}
                    </span>
                    <a
                      href={pubchemProfile.pubchemRecordUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-cyan-400 hover:underline inline-flex items-center gap-1 font-medium"
                    >
                      <span>PubChem Kaydını Aç</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  </div>
                </div>

                {/* Right 7 Columns: Physicochemical & Ankara Infrastructure Risk Correlation */}
                <div className="lg:col-span-7 bg-[#111827] border border-slate-800 rounded-xl p-5 space-y-4 flex flex-col justify-between">
                  <div className="space-y-4">
                    <h4 className="text-sm font-semibold text-white">
                      Fizikokimyasal Parametreler ve Ankara Altyapı Korelasyonu
                    </h4>

                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 font-mono tabular-nums">
                      <div className="p-3 bg-[#0B0E17] border border-slate-800 rounded-lg">
                        <span className="block text-[10px] text-slate-400">MOLEKÜLER FORMÜL</span>
                        <span className="text-base font-bold text-cyan-300">
                          {pubchemProfile.molecularFormula}
                        </span>
                      </div>
                      <div className="p-3 bg-[#0B0E17] border border-slate-800 rounded-lg">
                        <span className="block text-[10px] text-slate-400">MOLEKÜL AĞIRLIĞI</span>
                        <span className="text-base font-bold text-white">
                          {pubchemProfile.molecularWeight}
                        </span>
                      </div>
                      <div className="p-3 bg-[#0B0E17] border border-slate-800 rounded-lg">
                        <span className="block text-[10px] text-slate-400">TOPOLOJİK KUTUPSAL ALAN</span>
                        <span className="text-base font-bold text-amber-300">
                          {pubchemProfile.tpsa} Å²
                        </span>
                      </div>
                      <div className="p-3 bg-[#0B0E17] border border-slate-800 rounded-lg">
                        <span className="block text-[10px] text-slate-400">AĞIR ATOM SAYISI</span>
                        <span className="text-sm font-semibold text-slate-200">
                          {pubchemProfile.heavyAtomCount}
                        </span>
                      </div>
                      <div className="p-3 bg-[#0B0E17] border border-slate-800 rounded-lg">
                        <span className="block text-[10px] text-slate-400">KOMPLEKSİTE</span>
                        <span className="text-sm font-semibold text-slate-200">
                          {pubchemProfile.complexity}
                        </span>
                      </div>
                      <div className="p-3 bg-[#0B0E17] border border-slate-800 rounded-lg">
                        <span className="block text-[10px] text-slate-400">NET YÜK</span>
                        <span className="text-sm font-semibold text-slate-200">
                          {pubchemProfile.charge}
                        </span>
                      </div>
                    </div>

                    <div className="p-3 bg-[#0B0E17] border border-slate-800 rounded-lg font-mono text-xs space-y-1">
                      <div>
                        <span className="text-slate-400">Canonical SMILES: </span>
                        <span className="text-cyan-300 break-all">{pubchemProfile.canonicalSmiles}</span>
                      </div>
                      <div>
                        <span className="text-slate-400">InChIKey: </span>
                        <span className="text-slate-200 break-all">{pubchemProfile.inchiKey}</span>
                      </div>
                    </div>

                    <div className="space-y-2 text-xs leading-relaxed">
                      <div className="p-3 bg-[#0B0E17] border border-slate-800 rounded-lg">
                        <div className="font-semibold text-amber-400 mb-1">
                          Ankara Altyapı Kaynağı:
                        </div>
                        <p className="text-slate-300">{pubchemProfile.infrastructureSource}</p>
                      </div>

                      <div className="p-3 bg-[#0B0E17] border border-slate-800 rounded-lg">
                        <div className="font-semibold text-rose-400 mb-1">
                          Sismik İkincil Tehlike Mekanizması:
                        </div>
                        <p className="text-slate-300">{pubchemProfile.seismicHazardMechanism}</p>
                      </div>

                      <div className="p-3 bg-[#0B0E17] border border-slate-800 rounded-lg">
                        <div className="font-semibold text-cyan-400 mb-1">
                          Birincil Risk Altındaki Ankara İlçeleri:
                        </div>
                        <p className="text-slate-300">{pubchemProfile.affectedDistrictsSummary}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* MODAL 4: POST-EARTHQUAKE SIMULATION RESULTS REPORT */}
        {activeModal === 'results' && postEarthquakeReport && (
          <div className="flex-1 overflow-y-auto p-6 space-y-5">
            {/* Top Scenario Completion Banner */}
            <div className="p-4 bg-[#111827] border border-slate-800 rounded-xl flex flex-wrap items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2.5">
                  <span
                    className={`px-2.5 py-0.5 text-xs font-mono font-bold rounded border ${
                      postEarthquakeReport.overallStatus === 'KRİTİK AFET DURUMU'
                        ? 'bg-rose-950/80 border-rose-500/60 text-rose-300'
                        : postEarthquakeReport.overallStatus === 'YÜKSEK UYARI'
                        ? 'bg-amber-950/80 border-amber-500/60 text-amber-300'
                        : 'bg-cyan-950/80 border-cyan-500/60 text-cyan-300'
                    }`}
                  >
                    [{postEarthquakeReport.overallStatus}]
                  </span>
                  <span className="text-sm font-bold text-white">
                    {postEarthquakeReport.faultName}
                  </span>
                </div>
                <div className="text-xs text-slate-400 font-mono">
                  Büyüklük: <strong className="text-rose-400">Mw {postEarthquakeReport.magnitudeMw.toFixed(1)}</strong> ·
                  Odak Derinliği: <strong className="text-cyan-400">{postEarthquakeReport.depthKm} km</strong> ·
                  Fay Tipi: {postEarthquakeReport.faultType} ·
                  Sismik Yayılım Süresi: {postEarthquakeReport.durationSec} sn
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                {onSwitchModal && (
                  <button
                    type="button"
                    onClick={() => onSwitchModal('matrix')}
                    className="px-3.5 py-2 text-xs font-semibold bg-[#0B0E17] hover:bg-slate-800 text-slate-200 border border-slate-700 rounded-lg transition-colors cursor-pointer"
                  >
                    Tüm 25 İlçe Tablosu
                  </button>
                )}
                {onSwitchModal && (
                  <button
                    type="button"
                    onClick={() => onSwitchModal('pubchem')}
                    className="px-3.5 py-2 text-xs font-semibold bg-[#0B0E17] hover:bg-slate-800 text-amber-300 border border-slate-700 rounded-lg transition-colors cursor-pointer"
                  >
                    Kimyasal Risk Analizi (PubChem)
                  </button>
                )}
                {onReplaySimulation && (
                  <button
                    type="button"
                    onClick={onReplaySimulation}
                    className="px-4 py-2 text-xs font-semibold bg-cyan-500 hover:bg-cyan-400 text-slate-950 rounded-lg transition-colors cursor-pointer"
                  >
                    Simülasyonu Tekrar Başlat
                  </button>
                )}
              </div>
            </div>

            {/* 6 Province-Wide Post-Earthquake Damage KPIs */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
              <div className="p-3 bg-[#111827] border border-slate-800 rounded-lg">
                <div className="text-[10px] text-slate-400">MAKSİMUM YER İVMESİ</div>
                <div className="text-lg font-mono font-bold tabular-nums text-rose-400 mt-0.5">
                  {postEarthquakeReport.maxPgaG.toFixed(3)}g
                </div>
                <div className="text-[11px] text-slate-400 font-mono">
                  MMI {postEarthquakeReport.maxMmiRoman} · {postEarthquakeReport.epicenterDistrictName}
                </div>
              </div>

              <div className="p-3 bg-[#111827] border border-slate-800 rounded-lg">
                <div className="text-[10px] text-slate-400">KRİTİK / UYARI İLÇE</div>
                <div className="text-lg font-mono font-bold tabular-nums text-amber-400 mt-0.5">
                  {postEarthquakeReport.warningDistrictCount} / 25 İlçe
                </div>
                <div className="text-[11px] text-slate-400 font-mono">
                  {postEarthquakeReport.criticalDistrictCount} Kritik Seviye
                </div>
              </div>

              <div className="p-3 bg-[#111827] border border-slate-800 rounded-lg">
                <div className="text-[10px] text-slate-400">ASKİ BORU KIRIĞI</div>
                <div className="text-lg font-mono font-bold tabular-nums text-sky-400 mt-0.5">
                  ~{postEarthquakeReport.totalEstimatedPipeBreaks} Nokta
                </div>
                <div className="text-[11px] text-slate-400 font-mono">
                  Asbest / Eski Şebeke
                </div>
              </div>

              <div className="p-3 bg-[#111827] border border-slate-800 rounded-lg">
                <div className="text-[10px] text-slate-400">BAŞKENTGAZ KESİNTİ</div>
                <div className="text-lg font-mono font-bold tabular-nums text-yellow-400 mt-0.5">
                  {postEarthquakeReport.totalGasShutoffSubscribers.toLocaleString('tr-TR')}
                </div>
                <div className="text-[11px] text-slate-400 font-mono">
                  Otomatik RMS Vana (Abone)
                </div>
              </div>

              <div className="p-3 bg-[#111827] border border-slate-800 rounded-lg">
                <div className="text-[10px] text-slate-400">BAŞKENT EDAŞ KESİNTİ</div>
                <div className="text-lg font-mono font-bold tabular-nums text-orange-400 mt-0.5">
                  {postEarthquakeReport.totalEdasOutageHouseholds.toLocaleString('tr-TR')}
                </div>
                <div className="text-[11px] text-slate-400 font-mono">
                  Etkilenen Hane (Alo 186)
                </div>
              </div>

              <div className="p-3 bg-[#111827] border border-slate-800 rounded-lg">
                <div className="text-[10px] text-slate-400">MEB ACİL DENETİM</div>
                <div className="text-lg font-mono font-bold tabular-nums text-emerald-400 mt-0.5">
                  {postEarthquakeReport.totalSchoolsRequiringInspection} Okul
                </div>
                <div className="text-[11px] text-slate-400 font-mono">
                  {postEarthquakeReport.highRiskTrafficCorridorCount} Kritik Kavşak
                </div>
              </div>
            </div>

            {/* Top 8 Hardest-Hit Districts Table */}
            <div className="space-y-2">
              <h3 className="text-sm font-semibold text-white">
                Depremden En Çok Etkilenen İlk 8 İlçe Sıralaması
              </h3>
              <div className="overflow-x-auto border border-slate-800 rounded-lg">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-[#131C2E] text-slate-300 border-b border-slate-800 font-semibold">
                      <th className="py-2.5 px-3">Sıra & İlçe</th>
                      <th className="py-2.5 px-3 text-right">Merkez Uzaklık</th>
                      <th className="py-2.5 px-3 text-right">Yer İvmesi (PGA)</th>
                      <th className="py-2.5 px-3 text-right">Şiddet (MMI)</th>
                      <th className="py-2.5 px-3 text-right">ASKİ Boru Kırığı</th>
                      <th className="py-2.5 px-3 text-right">Başkentgaz Kesme</th>
                      <th className="py-2.5 px-3 text-right">EDAŞ Kesinti Hane</th>
                      <th className="py-2.5 px-3 text-right">Hasar Skoru</th>
                      <th className="py-2.5 px-3 text-right">3B Sahne</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/70 font-mono tabular-nums">
                    {postEarthquakeReport.topImpactedDistricts.map((imp, idx) => (
                      <tr
                        key={imp.districtId}
                        className="hover:bg-slate-800/50 transition-colors text-slate-200"
                      >
                        <td className="py-2.5 px-3 font-sans font-semibold text-white whitespace-nowrap">
                          <span className="font-mono text-cyan-400 mr-1.5">#{idx + 1}</span>
                          {imp.districtName}
                        </td>
                        <td className="py-2.5 px-3 text-right text-slate-400">
                          {imp.epicentralDistanceKm} km (x{imp.soilAmplificationFactor})
                        </td>
                        <td className="py-2.5 px-3 text-right font-bold text-amber-300">
                          {imp.pgaG.toFixed(3)}g
                        </td>
                        <td className="py-2.5 px-3 text-right text-cyan-300">
                          MMI {imp.mmiRoman}
                        </td>
                        <td className="py-2.5 px-3 text-right text-sky-300">
                          ~{imp.estimatedAsbestosPipeBreaks} Nokta (%{imp.askiPipeBreakProbabilityPercent})
                        </td>
                        <td className="py-2.5 px-3 text-right text-yellow-300">
                          %{imp.baskentgazShutoffPercent}
                        </td>
                        <td className="py-2.5 px-3 text-right text-rose-300">
                          {imp.edasOutageHouseholds.toLocaleString('tr-TR')}
                        </td>
                        <td className="py-2.5 px-3 text-right font-bold">
                          <span
                            className={
                              imp.compositeDamageScore >= 65
                                ? 'text-rose-400'
                                : imp.compositeDamageScore >= 38
                                ? 'text-amber-400'
                                : 'text-emerald-400'
                            }
                          >
                            {imp.compositeDamageScore}/100
                          </span>
                        </td>
                        <td className="py-2.5 px-3 text-right font-sans">
                          <button
                            type="button"
                            onClick={() => {
                              onSelectDistrictFromMatrix(imp.districtId);
                              onClose();
                            }}
                            className="px-2.5 py-1 text-xs font-medium bg-cyan-500/20 text-cyan-300 hover:bg-cyan-500 hover:text-slate-950 rounded transition-colors whitespace-nowrap cursor-pointer"
                          >
                            3B İncele
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Emergency Response Directives across Ankara Agencies */}
            <div className="space-y-2">
              <h3 className="text-sm font-semibold text-white">
                Kurumsal Acil Müdahale ve Altyapı Eylem Direktifleri
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {postEarthquakeReport.actionDirectives.map((item) => (
                  <div
                    key={item.agency}
                    className="p-3.5 bg-[#111827] border border-slate-800 rounded-lg space-y-1.5"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-cyan-400">{item.agency}</span>
                      <span className="text-[11px] font-mono text-amber-400">
                        Acil Hat: {item.hotline}
                      </span>
                    </div>
                    <p className="text-xs text-slate-300 leading-relaxed">{item.directive}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
